# HolyLens PCG — remote plugin

Connects to https://service.holylens.com/mcp using Streamable HTTP. No Node.js or local gateway is required.

Install this folder through a Codex plugin marketplace. Start a new task and ask to analyze heart sounds. Open the returned upload link, choose the recording, upload it, then return and say that uploading is complete.

Accepts WAV/WAVE/MP3/RAW/PCM up to 25 MB. RAW/PCM requires a known sample rate and mono signed 16-bit little-endian data. Links expire after 15 minutes; recordings are temporarily held in server memory and consumed once. Outputs are research results, not clinical diagnoses.

If Gateway:ApiKey is enabled, configure the client to send the operator-issued X-API-Key header separately. Never include a shared secret in a distributed package.